//This will output when the page loads
document.write("Output Zero Here");

//This will output when a button is pressed
function therest(){
	document.ElementById("output3").innerHTML="Output Three Here";
}

