/A Function to printout Hurrah! when called

function pushMe(){
	document.getElementBy("output").innerHTML="Hurrah!";
}


